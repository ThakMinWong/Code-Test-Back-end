package dk.danskebank.Account_Management_System.exception;

public class InvalidInputException extends Exception {
	private static final long serialVersionUID = -9156771067296250288L;

	public InvalidInputException() {
		super();
	}

	public InvalidInputException(String msg) {
		super(msg);
	}

	public InvalidInputException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
