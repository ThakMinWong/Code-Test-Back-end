package dk.danskebank.Account_Management_System.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Account {

	String id;
	
	String holderName;
	// This can be either individual or company, etc.
	String holderType;
	
	//This can be checking, savings, etc.
	String type;
	//Only usd for this example
	String currency;
	
	//In usd
	BigDecimal balance;
	
	private List<String> transactions;
	
	public Account() {
		
	}

	public Account(String id, String holderName, String holderType,String type, String currency) {
		super();
		this.id = id;
		this.holderName =holderName;
		this.holderType = holderType;
		this.type = type;
		this.currency = currency;
		this.balance = BigDecimal.ZERO;
		this.transactions = new ArrayList<String>();
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getHolderType() {
		return holderType;
	}

	public void setHolderType(String holderType) {
		this.holderType = holderType;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
    public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<String> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<String> transactions) {
		this.transactions = transactions;
	}

	@Override
    public String toString() {
        return String.format(
                "Account [id=%s, holder name=%s, holder type=%s, type=%s, balance=%s]", id, holderName,
                holderType, type, balance.toPlainString());
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Account other = (Account) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }

}
