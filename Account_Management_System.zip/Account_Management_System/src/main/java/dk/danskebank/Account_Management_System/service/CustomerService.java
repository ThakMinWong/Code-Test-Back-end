package dk.danskebank.Account_Management_System.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import dk.danskebank.Account_Management_System.exception.InvalidInputException;
import dk.danskebank.Account_Management_System.model.Account;
import dk.danskebank.Account_Management_System.model.Customer;

@Service
public class CustomerService {

	private static final List<Customer> customers = new ArrayList<>();
	private final SecureRandom random = new SecureRandom();
	private static final SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy:HH.mm.ss");

	static {
		// Initialize Data
		Account account1 = new Account("Account1", "JD", "Individual", "Checking", "usd");
		Account account2 = new Account("Account2", "JD", "Individual", "Savings", "usd");
		Account account3 = new Account("Account3", "JD_aps", "Company", "Checking", "usd");

		Customer jd = new Customer("Customer1", "John Doe", "Entrepreneur",
				new ArrayList<>(Arrays.asList(account1, account2)));
		Customer jd_aps = new Customer("Customer2", "JD aps", "John Doe companay",
				new ArrayList<>(Arrays.asList(account3)));

		customers.add(jd);
		customers.add(jd_aps);

	}

	public Customer getCustomer(String customerId) throws InvalidInputException {

		for (Customer customer : customers) {
			if (customer.getId().equals(customerId)) {
				return customer;
			}
		}

		throw new InvalidInputException("Customer Id is not found: " + customerId);

	}

	public List<Account> getAccounts(String customerId) throws InvalidInputException {
		Customer customer = getCustomer(customerId);
		return customer == null ? null : customer.getAccounts();
	}

	public Account getAccount(String customerId, String accountId) throws InvalidInputException {
		Customer customer = getCustomer(customerId);

		for (Account account : customer.getAccounts()) {
			if (account.getId().equals(accountId)) {
				return account;
			}
		}

		throw new InvalidInputException("Requested account Id is not found: " + 
		"Customer Id: " + customerId + ", Account Id: " + accountId);
	}

	public Account createAccount(String customerId, Account account) throws InvalidInputException{
			
		Customer customer = getCustomer(customerId);

		String randomId = new BigInteger(139, random).toString(32);
		account.setId(randomId);

		customer.getAccounts().add(account);

		return account;
	}

	public Account deposit(String customerId, String accountId, String amount) throws InvalidInputException, NumberFormatException {

		Customer customer = getCustomer(customerId);

		for (Account account : customer.getAccounts()) {
			if (account.getId().equals(accountId)) {
				//Note: potential rounding errors. 
				BigDecimal deposit = BigDecimal.valueOf(Math.abs(Double.valueOf(amount).doubleValue()));
				
				account.setBalance(account.getBalance().add(deposit));
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				account.getTransactions().add(String.format("Deposit [Timestamp:%s, amount=%s, balance=%s]",
						sdf.format(timestamp), amount, account.getBalance().toPlainString()));
				return account;
			}
		}
		
		throw new InvalidInputException("Requested amount not deposited as account Id is not found: " + 
		"Customer Id: " + customerId + ", Account Id: " + accountId);
	}

	public Account withdraw(String customerId, String accountId, String amount) throws InvalidInputException, NumberFormatException {

		Customer customer = getCustomer(customerId);

		for (Account account : customer.getAccounts()) {
			if (account.getId().equals(accountId)) {

				BigDecimal withdraw = BigDecimal.valueOf(Math.abs(Double.valueOf(amount).doubleValue()));
				// Assume no overdrawn credits
				if (account.getBalance().compareTo(withdraw) >= 0) {
					account.setBalance(account.getBalance().subtract(withdraw));
					Timestamp timestamp = new Timestamp(System.currentTimeMillis());
					account.getTransactions().add(String.format("Withdraw [Timestamp:%s, amount=%s, balance=%s]",
							sdf.format(timestamp), amount, account.getBalance().toPlainString()));

				} else {
					throw new InvalidInputException("Insufficient funds to withdraw (" + withdraw.toPlainString() + ") from account: " + 
							"Customer Id: " + customerId + ", Account Id: " + accountId + ", Balance: " + account.getBalance().toPlainString());
					
				}
				return account;
			}
			
		}
		
		throw new InvalidInputException("Requested amount not withdrawn as account Id is not found: " + 
		"Customer Id: " + customerId + ", Account Id: " + accountId);
	}

	public String getAvailableBalance(String customerId, String accountId) throws InvalidInputException {
		Customer customer = getCustomer(customerId);

		for (Account account : customer.getAccounts()) {
			if (account.getId().equals(accountId)) {
				return account.getBalance().toPlainString();
			}
		}

		throw new InvalidInputException("Requested balance is not known as account Id is not found: " + 
		"Customer Id: " + customerId + ", Account Id: " + accountId);
	}

	public List<String> getTransactions(String customerId, String accountId, String lastNumTransactions) throws InvalidInputException, NumberFormatException {

		Customer customer = getCustomer(customerId);

		List<String> list = new ArrayList<String>();

		int num = Math.abs(Integer.parseInt(lastNumTransactions));
				
		for (Account account : customer.getAccounts()) {
			if (account.getId().equals(accountId)) {
				int size = account.getTransactions().size(), count = 0;

				// Return the stored list of transactions in reversed order.
				for (int i = size - 1; i > -1 && ++count <= num; i--) {
					list.add(account.getTransactions().get(i));
				}
				return list;
			}
		}

		throw new InvalidInputException("Requested transactions are unavailable as account Id is not found: " + 
		"Customer Id: " + customerId + ", Account Id: " + accountId);
	}
}
