package dk.danskebank.Account_Management_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
