package dk.danskebank.Account_Management_System.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import dk.danskebank.Account_Management_System.model.Account;
import dk.danskebank.Account_Management_System.service.CustomerService;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = CustomerController.class)
public class CustomerControllerTest {

	@Autowired
    private MockMvc mockMvc;

	@MockBean
	private CustomerService customerService;
	
	private static final SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy:HH.mm.ss");
	
	String exampleAccountJson = "{\"holderType\":\"individual\",\"type\":\"checking\",\"currency\":\"usd\",\"balance\":\"0.0\"}";
/*
		this.id = id;
		this.holderName =holderName;
		this.holderType = holderType;
		this.type = type;
		this.currency = currency;
		this.balance = balance;
		this.transactions = new ArrayList<String>(); */
	
	@Test
	public void createAccount() throws Exception {
		
		Account mockAccount = new Account("1", "One John Doe", "individual",  "checking", "usd");
		Mockito.when(customerService.createAccount(Mockito.anyString(), Mockito.any(Account.class))).thenReturn(mockAccount);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/customer/Customer1/account").accept(MediaType.APPLICATION_JSON).content(exampleAccountJson).contentType(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.CREATED.value(), response.getStatus());

        assertEquals("http://localhost/customer/Customer1/account/1",
                response.getHeader(HttpHeaders.LOCATION));
	}
	
	@Test
	public void depositMoney() throws Exception {
		
		Account mockAccount = new Account("1", "One John Doe", "individual",  "checking", "usd");
		mockAccount.setBalance(BigDecimal.valueOf(100));
		
		Mockito.when(customerService.deposit(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(mockAccount);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/customer/Customer1/account/1/deposit/100").accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		
        MockHttpServletResponse response = result.getResponse();
        
        assertEquals(HttpStatus.CREATED.value(), response.getStatus());

        assertEquals("http://localhost/customer/Customer1/account/1/deposit/100/balance/100",
                response.getHeader(HttpHeaders.LOCATION));	
 
	}
	
	@Test
	public void withdrawMoney() throws Exception {
		
		Account mockAccount = new Account("1", "One John Doe", "individual",  "checking", "usd");
		mockAccount.setBalance(BigDecimal.valueOf(50));

		Mockito.when(customerService.withdraw(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(mockAccount);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/customer/Customer1/account/1/withdraw/50").accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		
        MockHttpServletResponse response = result.getResponse();
        
        assertEquals(HttpStatus.CREATED.value(), response.getStatus());

        assertEquals("http://localhost/customer/Customer1/account/1/withdraw/50/balance/50",
                response.getHeader(HttpHeaders.LOCATION));			
	}
	
	
	@Test
	public void retrieveBalance() throws Exception {
		String balance = "100";
		Mockito.when(customerService.getAvailableBalance(Mockito.anyString(), Mockito.anyString())).thenReturn(balance);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/customer/Customer1/account/1/balance").accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        assertEquals(balance, result.getResponse().getContentAsString());

	}
	
	@Test
	public void retrieveLastTransactions() throws Exception {
		
		String amount = "100";
		Account mockAccount = new Account("1", "One John Doe", "individual",  "checking", "usd");
		mockAccount.setBalance(BigDecimal.valueOf(Integer.parseInt(amount)));
		
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());		
		String transaction = String.format("Deposit [Timestamp:%s, amount=%s, balance=%s]",
				sdf.format(timestamp), amount, mockAccount.getBalance().toPlainString());
		mockAccount.getTransactions().add(transaction);		
		
		Mockito.when(customerService.getTransactions(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(mockAccount.getTransactions());
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/customer/Customer1/account/1/lastNumTrans/10").accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        
        assertEquals("[\"" + transaction + "\"]", result.getResponse().getContentAsString());		
	}
	
	
}