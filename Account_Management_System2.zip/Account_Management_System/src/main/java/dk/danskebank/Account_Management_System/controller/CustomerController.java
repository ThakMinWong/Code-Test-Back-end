package dk.danskebank.Account_Management_System.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import dk.danskebank.Account_Management_System.exception.InvalidInputException;
import dk.danskebank.Account_Management_System.model.Account;
import dk.danskebank.Account_Management_System.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@PostMapping("/customer/{customerId}/account")
	public ResponseEntity<Void> createAccount(@PathVariable String customerId, @RequestBody Account newAcount) {

		try {
			Account account = customerService.createAccount(customerId, newAcount);

			if (account == null) {
				return ResponseEntity.noContent().build();
			}

			URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
					.buildAndExpand(account.getId()).toUri();

			return ResponseEntity.created(location).build();

		} catch (InvalidInputException iie) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, iie.getMessage(), iie);
		}
	}

	@PutMapping("/customer/{customerId}/account/{accountId}/deposit/{amount}")
	public ResponseEntity<Void> depositMoney(@PathVariable String customerId, @PathVariable String accountId,
			@PathVariable String amount) {

		try {
			Account account = customerService.deposit(customerId, accountId, amount);

			if (account == null) {
				return ResponseEntity.noContent().build();
			}

			URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/balance/{balance}")
					.buildAndExpand(account.getBalance()).toUri();

			return ResponseEntity.created(location).build();
		} catch (InvalidInputException iie) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, iie.getMessage(), iie);
		} catch (NumberFormatException nfe) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, nfe.getMessage(), nfe);
		}

	}

	@PutMapping("/customer/{customerId}/account/{accountId}/withdraw/{amount}")
	public ResponseEntity<Void> withdrawMoney(@PathVariable String customerId, @PathVariable String accountId,
			@PathVariable String amount) {

		try {
			Account account = customerService.withdraw(customerId, accountId, amount);

			if (account == null) {
				return ResponseEntity.noContent().build();
			}

			URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/balance/{balance}")
					.buildAndExpand(account.getBalance()).toUri();

			return ResponseEntity.created(location).build();
		} catch (InvalidInputException iie) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, iie.getMessage(), iie);
		} catch (NumberFormatException nfe) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, nfe.getMessage(), nfe);
		}

	}

	@GetMapping("/customer/{customerId}/account/{accountId}/balance")
	public String retrieveBalance(@PathVariable String customerId, @PathVariable String accountId) {
		try {
			return customerService.getAvailableBalance(customerId, accountId);

		} catch (InvalidInputException iie) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, iie.getMessage(), iie);
		}
	}

	@GetMapping("/customer/{customerId}/account/{accountId}/lastNumTrans/{lastNumTransactions}")
	public List<String> retrieveLastTransactions(@PathVariable String customerId, @PathVariable String accountId,
			@PathVariable String lastNumTransactions) {

		try {
			return customerService.getTransactions(customerId, accountId, lastNumTransactions);

		} catch (InvalidInputException iie) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, iie.getMessage(), iie);
		} catch (NumberFormatException nfe) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, nfe.getMessage(), nfe);
		}
	}
}
